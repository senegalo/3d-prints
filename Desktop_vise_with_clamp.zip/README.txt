                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3403208
Desktop vise with clamp by Stealth_NT is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

For additional information please check the original sources.

The vise mod I made its because sometimes I hold hot stuff with it and overtime the jaws get damaged, now with jaws cover that its no problem at all since I just need new covers and that can be printed in no time.

I adapted the clamp to only hold in place the vise so there is no way the vice slip or move unless the clamp its broken. Part of the clamp goes inside the vice for secure grip.





# Print Settings

Printer: Qidi Tech 1
Rafts: No
Supports: No
Resolution: .2
Infill: 35
Filament_brand: Hatchbox
Filament_color: White/Blue
Filament_material: ABS

Notes: 
Infill of your choice of course more strength you want more infill you need, 4-4-4 solid layers are recommended (top-button-perimeters) for beter strength.

I used ABS because my temps but can be printed on anything you like, I also have another one made on PLA.